const express = require("express")
const bodyParser = require("body-parser")
const admin = require('firebase-admin');
const handlebars = require('express-handlebars')

const app = express();
const PORT = 3000;

//configuração do handlebars
app.engine("handlebars", handlebars.engine({ defaultLayout: "main" }));
app.set("view engine", "handlebars");
app.set("views", "./views"); // Define a pasta das views

//configuração do BodyParser
app.use(bodyParser.urlencoded({ extended: true }));

// Inicializa o Firebase
const serviceAccount = require('./firebase-config.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://nodejs-5675d-default-rtdb.firebaseio.com/' // URL do seu banco de dados Firebase
});

const db = admin.database();


// Rota para o formulário e lista de usuários
app.get("/users", (req, res) => {
    db.ref("users")
      .once("value")
      .then((snapshot) => {
        const users = snapshot.val() || {};
        res.render("consulta", { users });
      })
      .catch((error) =>
        res.status(500).send("Erro ao buscar dados: " + error.message)
      );
  });

// Rota para remover um usuário pelo ID
app.post("/delete", (req, res) => {
    const id = req.body.id;
  
    // Valida o ID
    if (!id) {
      return res.status(400).send("ID é obrigatório para deletar um usuário.");
    }
  
    // Remove o registro do Firebase
    db.ref("users/" + id)
      .remove()
      .then(() => res.send("Usuário removido com sucesso do Firebase!"))
      .catch((error) =>
        res.status(500).send("Erro ao remover usuário: " + error.message)
      );
  });
  







app.get('/',(req,res)=>{
    res.sendFile(__dirname + '/html/index.html')
})

// Rota para receber dados do formulário
app.post('/submit', (req, res) => {
    const id = req.body.id
    const nome = req.body.nome;
    
    // Valida os dados
  if (!id || !nome) {
    return res.status(400).send('Campos ID e Nome são obrigatórios.');
  }

  // Salva os dados no Firebase
  db.ref('users/' + id).set({ nome })
    .then(() => res.send('Dados salvos com sucesso no Firebase!'))
    .catch(error => res.status(500).send('Erro ao salvar dados: ' + error.message));


})







app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
  });





