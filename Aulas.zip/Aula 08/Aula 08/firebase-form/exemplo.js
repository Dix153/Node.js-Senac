const express = require('express');
const bodyParser = require('body-parser');
const admin = require('firebase-admin');

const app = express();
const PORT = 3000;

// Inicializa o Firebase
const serviceAccount = require('./firebase-config.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://nodejs-5675d-default-rtdb.firebaseio.com/' // URL do seu banco de dados Firebase
});

const db = admin.database();

// Middleware para processar os dados do formulário
app.use(bodyParser.urlencoded({ extended: true }));

// Servir um formulário HTML básico
app.get('/', (req, res) => {
  res.send(`
    <form action="/submit" method="POST">
      <label for="id">ID:</label>
      <input type="text" name="id" id="id" required />
      <label for="nome">Nome:</label>
      <input type="text" name="nome" id="nome" required />
      <button type="submit">Enviar</button>
    </form>
  `);
});

// Rota para receber dados do formulário
app.post('/submit', (req, res) => {
  const { id, nome } = req.body;

  // Valida os dados
  if (!id || !nome) {
    return res.status(400).send('Campos ID e Nome são obrigatórios.');
  }

  // Salva os dados no Firebase
  db.ref('users/' + id).set({ nome })
    .then(() => res.send('Dados salvos com sucesso no Firebase!'))
    .catch(error => res.status(500).send('Erro ao salvar dados: ' + error.message));
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
