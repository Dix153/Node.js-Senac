// Importa o módulo express (framework web para Node.js)
const express = require('express')

// Importa o módulo express-handlebars (motor de template Handlebars para Express)
const handlebars = require('express-handlebars')

// Importa o módulo body-parser (para parsear dados de requisições POST)
const bodyParser = require('body-parser')

// Cria uma instância do Express (aplicação web)
const app = express()

// Define a porta em que o servidor irá rodar
const port = 3000

// Configuração do motor de template Handlebars
app.engine("handlebars", handlebars.engine({ defaultLayout: "main" })) // Define o motor de template Handlebars, com "main" como layout padrão
app.set("view engine", "handlebars") // Informa ao Express que o motor de visualização a ser usado será o Handlebars
app.set("views", "./views") // Define o diretório onde as views (templates) serão encontradas, neste caso a pasta "views"

// Configuração do body-parser para processar dados das requisições POST
app.use(bodyParser.urlencoded({ extended: true })) // Lê dados de formulários no formato URL-encoded
app.use(bodyParser.json()) // Lê dados no formato JSON (geralmente para APIs)

// Rota GET para a página inicial
app.get('/', (req, res) => {
    // Renderiza a view "index" e passa os dados "nome" e "idade" para o template
    res.render('index', { nome: 'Andre', idade: 29 })
})

// Rota POST para receber dados de um formulário
app.post('/form', (req, res) => {
    // Envia o nome enviado no corpo da requisição como resposta
    res.send(req.body.nome)  // O valor de "req.body.nome" será enviado de volta como resposta
})

// Inicia o servidor na porta 3000
app.listen(port, () => {
    // Imprime no console a mensagem indicando que o servidor está rodando
    console.log(`Servidor rodando em http://localhost:${port}`)
})


